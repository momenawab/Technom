import 'package:flutter/material.dart';

import 'Screens/Screen2.dart';
import 'Screens/reset_password_page.dart'; // Update the path accordingly

void main() {
  runApp(LoginApp());
}

class LoginApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Login Page',
      theme: ThemeData(
        primaryColor: Colors.purple,
        fontFamily: 'Roboto',
      ),
      home: LoginPage(),
    );
  }
}

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  bool _isEnglish = true;
  String _username = '';
  String _password = '';

  void _toggleLanguage() {
    setState(() {
      _isEnglish = !_isEnglish;
    });
  }

  void _login() {
    // Perform login logic here
    print('Username: $_username');
    print('Password: $_password');
    Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => Screen2()),);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: Text(
          _isEnglish ? 'Login' : 'تسجيل الدخول',
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,

        backgroundColor: Colors.transparent,
        elevation: 0,

      ),
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage("img/back.jpg"), // Replace with your own image path
            fit: BoxFit.cover,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextField(
                style: TextStyle(color: Colors.white),
                obscureText: false,
                decoration: InputDecoration(
                  labelText: _isEnglish ? 'Username' : 'اسم المستخدم',
                  labelStyle: TextStyle(color: Colors.white),
                ),
                onChanged: (value) {
                  setState(() {
                    _username = value;
                  });
                },
              ),
              const SizedBox(height: 16.0),
              TextField(
                onChanged: (value) {
                  setState(() {
                    _password = value;
                  });
                },
                style: TextStyle(color: Colors.white),

                obscureText: true,
                decoration: InputDecoration(
                  labelText: _isEnglish ? 'Password' : 'كلمة المرور',
                  labelStyle: TextStyle(color: Colors.white),
                ),
              ),
              const SizedBox(height: 16.0),
              TextButton(
                onPressed: () { Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => ResetPasswordPage()),);
                  // Perform forgot password logic here
                  print(_isEnglish ? 'Forgot Password' : 'نسيت كلمة المرور');
                },
                child: Text(
                  _isEnglish ? 'Forgot Password?' : 'نسيت كلمة المرور؟',
                  style: const TextStyle(color: Colors.purple),
                ),
              ),
              const SizedBox(height: 16.0),
              ElevatedButton(
                onPressed: _login,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.purple,
                ),
                child: Text(
                  _isEnglish ? 'Login' : 'تسجيل الدخول',
                  style: const TextStyle(color: Colors.white),
                ),
              ),
              const SizedBox(height: 16.0),
              TextButton(
                onPressed: _toggleLanguage,
                child: Text(
                  _isEnglish ? 'تغيير اللغة' : 'Change Language',
                  style: const TextStyle(color: Colors.white),
                ),
              ),
              const Text(
                "Technom",
                style: TextStyle(color: Colors.white),
              ),
              Image.asset(
                'img/logo.png',
                width: 120,
                height: 200,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

