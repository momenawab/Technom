import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'Screen11.dart';
import 'Screen2.dart';

void main() {
  runApp(const MyAppp());
}

class MyAppp extends StatelessWidget {

  const MyAppp({super.key});



  @override
  Widget build(BuildContext context) {
    return const MaterialApp(

      debugShowCheckedModeBanner: false,
      title: 'Button Page',
      home: ButtonPage(),
    );
  }
}

class ButtonPage extends StatefulWidget {
  const ButtonPage({super.key});

  @override
  _ButtonPageState createState() => _ButtonPageState();
}

class _ButtonPageState extends State<ButtonPage> {
  bool showTextFields = false;
  bool showOfficeExpensesButtons = false;
  bool showFeesButtons = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,

      extendBodyBehindAppBar: true,
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.home),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => Screen2()),
            );
          },
        ),
        title: const Text('المالية'),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0,
         // Navigate back to Screen1
        ),
      body: BackgroundImage(
        showTextFields: showTextFields,
        showOfficeExpensesButtons: showOfficeExpensesButtons,
        showFeesButtons: showFeesButtons,
        onPressedTahseel: () {
          setState(() {
            showTextFields = true;
            showOfficeExpensesButtons = false;
            showFeesButtons = false;
          });
        },        context: context,

        onPressedExpenses: () {
          setState(() {
            showTextFields = false;
            showOfficeExpensesButtons = true;
            showFeesButtons = false;
          });
        },
        onPressedFees: () {
          setState(() {
            showTextFields = false;
            showOfficeExpensesButtons = false;
            showFeesButtons = true;
          });
        },
      ),
    );
  }
}

class BackgroundImage extends StatelessWidget {
  final bool showTextFields;
  final bool showOfficeExpensesButtons;
  final bool showFeesButtons;
  final VoidCallback onPressedTahseel;
  final VoidCallback onPressedExpenses;
  final VoidCallback onPressedFees;

  const BackgroundImage({super.key,
    required this.showTextFields,
    required this.showOfficeExpensesButtons,
    required this.showFeesButtons,
    required this.onPressedTahseel,
    required this.onPressedExpenses,
    required this.onPressedFees, required BuildContext context,

  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        image: DecorationImage(
          image: AssetImage('img/back.jpg'),
          fit: BoxFit.cover,
        ),
      ),
      child: Column(
        children: [
          const SizedBox(height: 120), // Add space at the top
          Align(
            alignment: Alignment.topCenter,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                ElevatedButton(
                  onPressed: onPressedTahseel,
                  style: ElevatedButton.styleFrom(
                    foregroundColor: Colors.white,
                    backgroundColor: Colors.purple,
                  ),
                  child: const Text('تحصيل الأموال'),
                ),
                const SizedBox(width: 20),
                ElevatedButton(
                  onPressed: onPressedExpenses,
                  style: ElevatedButton.styleFrom(
                    foregroundColor: Colors.white, backgroundColor: Colors.purple,
                  ),
                  child: const Text('مصاريف المكتب'),
                ),
                const SizedBox(width: 20),
                ElevatedButton(
                  onPressed: onPressedFees,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.purple,
                    onPrimary: Colors.white,
                  ),
                  child: const Text('رسوم'),
                ),
              ],
            ),
          ),
          if (showTextFields) ...generateTextFields(),
          if (showOfficeExpensesButtons) ...generateOfficeExpensesButtons(),
          if (showFeesButtons) ...generateFeesButtons(),
        ],
      ),
    );
  }

  List<Widget> generateTextFields() {
    List<String> texts = [
      '  المحصل منه ◀',
      '           صفته  ◀',
      '          تابع ل ◀',
      'المبلغ المحصل◀',
      '  المبلغ المتبقي◀',
      ' طريقة الدفع ◀',
      '    نظام الدفع◀',
      '   عدد الدفعات◀'
    ];

    return texts.map((text) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 5.0),
        child: Row(
          children: [
            const Expanded(
              child: TextField(
                style: TextStyle(color: Colors.white),
                decoration: InputDecoration(

                  hintStyle: TextStyle(color: Colors.white),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.purple), // Change border color here
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.white),)
                ),
              ),
            ),
            const SizedBox(width: 10),
            Text(
              text,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ],
        ),
      );
    }).toList();
  }

  List<Widget> generateOfficeExpensesButtons() {
    List<String> buttons = [
      'الإيجار',
      'الرواتب',
      'مصاريف مكتبية',
      'اعلانات',
      'صيانة ',
      'مصاريف أخرى',
    ];

    List<Widget> rows = [];
    for (int i = 0; i < buttons.length; i += 3) {
      rows.add(Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: buttons.sublist(i, i + 3).map((button) {
          return Padding(
            padding: const EdgeInsets.all(8.0),
            child: ElevatedButton(
              onPressed: () {
                // Add your button's onPressed logic here
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.deepPurple,
                onPrimary: Colors.white,
              ),
              child: Text(button),
            ),
          );
        }).toList(),
      ));
    }

    return rows;
  }

  List<Widget> generateFeesButtons() {
    List<String> buttons = [
      'رسوم رفع دعوى',
      'رسوم تحصيل',
      'رسوم معاملة',
      'رسوم اخرى',
      'إشعار بدفع الرسوم',
    ];

    return [
      Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          ElevatedButton(
            onPressed: () {
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.deepPurple,
              onPrimary: Colors.white,
            ),
            child: Text(buttons[0]),
          ),
          const SizedBox(width: 20),
          ElevatedButton(
            onPressed: () {
              // Add your button's onPressed logic here
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.deepPurple,
              onPrimary: Colors.white,
            ),
            child: Text(buttons[1]),
          ),
        ],
      ),
      Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: buttons.sublist(2).map((button) {
          return Padding(
            padding: const EdgeInsets.all(8.0),
            child: ElevatedButton(
              onPressed: () {
                // Add your button's onPressed logic here
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.deepPurple,
                onPrimary: Colors.white,
              ),
              child: Text(button),
            ),
          );
        }).toList(),
      ),
    ];
  }
}
