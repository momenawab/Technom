import 'package:flutter/material.dart';
import 'package:untitled9/Screens/Screen2.dart';
void main() {
  runApp(MyyApp());
}

class MyyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.home),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => Screen2()),
            );
          },
        ),

        title: const Text(
          'الإستعلام',
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('img/back.jpg'),
                fit: BoxFit.fill,
              ),
            ),
          ),
          Positioned(
            bottom: 20,
            left: 150,
            child: Image.asset(
              'img/logo.png',
              width: 100,
              height: 100,
            ),
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton(
                onPressed: () {
                  // Perform action for button 1
                },
                style: ElevatedButton.styleFrom(backgroundColor: Colors.purple),
                child: Text('  التنبيهات  '),
              ),
              SizedBox(width: 2000, height: 65,),
              ElevatedButton(
                onPressed: () {
                  // Perform action for button 2
                },
                style: ElevatedButton.styleFrom(backgroundColor: Colors.purple),
                child: const Text('المستجدات', style: TextStyle(color: Colors.white)),
              ),
              SizedBox(height: 30),
            ],
          ),
        ],
      ),
    );
  }
}

