import 'package:flutter/material.dart';
import 'Screen5.1.dart';
import 'Screen2.dart';
void main() {
  runApp(galasat());
}

class galasat extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: MyPage(),
    );
  }
}

class MyPage extends StatefulWidget {
  @override
  _MyPageState createState() => _MyPageState();
}

class _MyPageState extends State<MyPage> {
  bool _showTextField = false;

  void _onButtonPressed() {
    setState(() {
      _showTextField = !_showTextField; // Toggle the visibility of the text field
    });
  }

  Widget _buildContent() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Directionality(
          textDirection: TextDirection.rtl,
          child: Text(
            '  ◀  عن الموكل',
            style: TextStyle(fontSize: 18, color: Colors.white),
          ),
        ),
        const SizedBox(height: 20),
        Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                OptionButton('تم تقديم مذكرة', () {}),
                SizedBox(width: 10),
                OptionButton('اجل الاعلان مع ارشاد ', () {}),
                SizedBox(width: 10),
                OptionButton('اجل الاعلان', () {}),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                OptionButton('طلبنا اجل للرد', () {}),
                SizedBox(width: 10),
                OptionButton('تم تقديم حافظة مستندات', () {}),
              ],
            ),
          ],
        ),
        SizedBox(height: 40), // Added spacing for the new button
        Center(
          child: ElevatedButton(
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => khesem()),);
              // Add your button's onPressed logic here
              // Add your button's onPressed function
            },
            style: ElevatedButton.styleFrom(
              primary: Colors.purple,
            ),
            child: Text(
              'اضافة الخصم',
              style: TextStyle(color: Colors.white),
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.home),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => Screen2()),
            );
          },
        ),
        title: const Text('جلسات الخبراء'),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('img/back.jpg'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          Positioned(
            top: 100,
            left: 0,
            right: 0,
            child: _buildContent(),
          ),
        ],
      ),
    );
  }
}

class OptionButton extends StatefulWidget {
  final String text;
  final VoidCallback onPressed;

  OptionButton(this.text, this.onPressed);

  @override
  _OptionButtonState createState() => _OptionButtonState();
}

class _OptionButtonState extends State<OptionButton> {
  bool isSelected = false;

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: () {
        setState(() {
          isSelected = !isSelected; // Toggle the selection state
        });
        widget.onPressed();
      },
      style: ElevatedButton.styleFrom(
        primary: isSelected ? Colors.grey : Colors.purple,
      ),
      child: Text(
        widget.text,
        style: TextStyle(
          color: isSelected ? Colors.white : null,
        ),
      ),
    );
  }
}
