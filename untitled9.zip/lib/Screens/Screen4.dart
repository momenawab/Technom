import 'package:flutter/material.dart';
import 'Screen2.dart';

void main() {
  runApp(ButtonApp());
}

class ButtonApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'الجلسات',

      home: ButtonPage(),
    );
  }
}

class ButtonPage extends StatefulWidget {
  @override
  _ButtonPageState createState() => _ButtonPageState();
}

class _ButtonPageState extends State<ButtonPage> {
  int selectedButtonIndex = -1;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.home),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => Screen2()),
            );
          },
        ),
        title: const Text('الجلسات'),
        centerTitle: true,
        backgroundColor: Colors.transparent,
      ),
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('img/back.jpg'),
            fit: BoxFit.cover,
            alignment: Alignment.center,
          ),
        ),
        child: Align(
          alignment: Alignment.center,
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                buildButton('اجل للاعلان', 0),
                const SizedBox(height: 20),
                buildButton('اجل للاعلان مع ارشاد', 1),
                const SizedBox(height: 20),
                buildButton('قريبا', 2),
                const SizedBox(height: 20),
                buildButton('قريبا', 3),
                const SizedBox(height: 20),
                const Text(
                  'ملاحظات',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 10),
                Container(
                  width: 250,
                  child: TextFormField(
                    style: const TextStyle(color: Colors.white),
                    decoration: const InputDecoration(
                      hintText: 'Enter something...',
                      hintStyle: TextStyle(color: Colors.white),
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () {},
                  child: const Text('تسليم'),
                  style: ElevatedButton.styleFrom(
                    primary: Colors.purple, // Change the button color to purple
                    onPrimary: Colors.white,
                    textStyle: const TextStyle(fontSize: 18),
                    padding:
                    const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget buildButton(String buttonText, int buttonIndex) {
    return ElevatedButton(
      onPressed: () {
        setState(() {
          if (selectedButtonIndex == buttonIndex) {
            selectedButtonIndex = -1; // Deselect the button
          } else {
            selectedButtonIndex = buttonIndex; // Select the button
          }
        });
      },
      child: Text(buttonText),
      style: ElevatedButton.styleFrom(
        primary:
        selectedButtonIndex == buttonIndex ? Colors.green : Colors.purple,
        onPrimary: Colors.white,
        textStyle: const TextStyle(fontSize: 16),
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      ),
    );
  }
}
