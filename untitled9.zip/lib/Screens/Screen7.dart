import 'package:flutter/material.dart';
import 'Screen2.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  const MyHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.home),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => Screen2()),
            );
          },
        ),
        title: const Text(
          'تحقيق',
        ),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: const BackgroundImage(),
    );
  }
}

class BackgroundImage extends StatelessWidget {
  const BackgroundImage({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        image: DecorationImage(
          image: AssetImage('img/back.jpg'),
          fit: BoxFit.cover,
        ),
      ),
      child: const Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            ' ما هو نوع التحقيق؟',
            style: TextStyle(fontSize: 24, color: Colors.white),
          ),
          SizedBox(height: 20),
          OptionsList(),
        ],
      ),
    );
  }
}

class OptionsList extends StatefulWidget {
  const OptionsList({super.key});

  @override
  _OptionsListState createState() => _OptionsListState();
}

class _OptionsListState extends State<OptionsList> {
  String selectedOption = '';
  List<String> selectedOptions = [];

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            OptionButton('لدى الادارة العامة للتحقيقات', () {
              toggleOption('Option 1');
            }, isSelected: selectedOption == 'Option 1'),
            const SizedBox(width: 10),
            OptionButton('لدى النيابة العامة', () {
              toggleOption('Option 2');
            }, isSelected: selectedOption == 'Option 2'),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            OptionButton('لدى جهة اخرى', () {
              toggleOption('Option 3');
            }, isSelected: selectedOption == 'Option 3'),
            const SizedBox(width: 10),
            OptionButton('لدى وزارة الشئون', () {
              toggleOption('Option 4');
            }, isSelected: selectedOption == 'Option 4'),
          ],
        ),
        if (selectedOption.isNotEmpty) ...generateTextFields(),
      ],
    );
  }

  void toggleOption(String option) {
    setState(() {
      if (selectedOptions.contains(option)) {
        selectedOptions.remove(option);
        selectedOption = '';
      } else {
        selectedOptions.clear();
        selectedOptions.add(option);
        selectedOption = option;
      }
    });
  }

  List<Widget> generateTextFields() {
    List<String> texts = ['تاريخ التحقيق   ◂', 'وقت التحقيق   ◂', 'مكان التحقيق   ◂', 'اسم المحقق   ◂', 'رقم الشكوي   ◂', 'رقم القضية   ◂', 'رقم أخر   ◂'];

    return texts.map((text) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 2.0, horizontal: 5.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          const Expanded(
            child: Row(
              children: [
                SizedBox(width: 5),
                Expanded(
                  child: TextField(
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.transparent,
                      border: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.green), // Set the border color to white
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Text(
            text,
            style: const TextStyle(fontSize: 18, color: Colors.white),
          ),
        ],
      ),
    )).toList();
  }
}

class OptionButton extends StatelessWidget {
  final String text;
  final VoidCallback onPressed;
  final bool isSelected;

  const OptionButton(this.text, this.onPressed, {super.key, this.isSelected = false});

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ButtonStyle(
        backgroundColor: isSelected ? MaterialStateProperty.all<Color>(Colors.grey) : MaterialStateProperty.all<Color>(Colors.purple),
      ),
      child: Text(text),
    );
  }
}
