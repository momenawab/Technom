import 'package:flutter/material.dart';
import 'Screen2.dart';
void main() {
  runApp(mangement());
}

class mangement extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        resizeToAvoidBottomInset: false,
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          leading: IconButton(
            icon: Icon(Icons.home),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => Screen2()),
              );
            },
          ),
          title: Text('إدارة العمل'),
          centerTitle: true,
          backgroundColor: Colors.transparent, // Set the background color to transparent
          elevation: 0, // Remove elevation
        ),
        body: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage('img/back.jpg'), // Adjust the image path
              fit: BoxFit.cover,
            ),
          ),
          child: Padding(
            padding: EdgeInsets.only(top: 150, left: 20, right: 20), // Adjust top padding as needed
            child: ButtonRow(),
          ),
        ),
      ),
    );
  }
}

class ButtonRow extends StatefulWidget {
  @override
  _ButtonRowState createState() => _ButtonRowState();
}

class _ButtonRowState extends State<ButtonRow> {
  List<Widget> rows = [];
  List<bool> isSelected = [false, true, false, false, false, false, false];

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(
              child: ElevatedButton(
                onPressed: () => _handleButtonPress(0),
                style: _getButtonStyle(isSelected[0]),
                child: Text('الأعمال المنجزة'),
              ),
            ),
            SizedBox(width: 20),
            Expanded(
              child: ElevatedButton(
                onPressed: () => _handleButtonPress(1),
                style: _getButtonStyle(isSelected[1]),
                child: Text('الترحيل'),
              ),

            ),

          ],
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(
              child: ElevatedButton(
                onPressed: () => _handleButtonPress(2),
                style: _getButtonStyle(isSelected[2]),
                child: Text('تقرير الإسبوع'),
              ),
            ),
            SizedBox(width: 20),
            Expanded(
              child: ElevatedButton(
                onPressed: () => _handleButtonPress(3),
                style: _getButtonStyle(isSelected[3]),
                child: Text('اعمال لم تنجز'),
              ),
            ),
          ],
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(
              child: ElevatedButton(
                onPressed: () => _handleButtonPress(4),
                style: _getButtonStyle(isSelected[4]),
                child: Text('تقرير الاسبوع القادم '),
              ),
            ),
            SizedBox(width: 20),
            Expanded(
              child: ElevatedButton(
                onPressed: () => _handleButtonPress(5),
                style: _getButtonStyle(isSelected[5]),
                child: Text('التقرير الشهري والسنوي'),
              ),
            ),
          ],
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(
              child: ElevatedButton(
                onPressed: () => _handleButtonPress(6),
                style: _getButtonStyle(isSelected[6]),
                child: Text('توزيع العمل'),
              ),
            ),
            SizedBox(width: 0),


          ],
        ),
        SizedBox(height: 50), // Adding some space between buttons and text fields
        Column(
          children: rows,
        ),
      ],
    );
  }

  void _handleButtonPress(int index) {
    setState(() {
      for (int i = 0; i < isSelected.length; i++) {
        if (i == index) {
          isSelected[i] = !isSelected[i];
        } else {
          isSelected[i] = false;
        }
      }

      if (isSelected[index]) {
        rows.clear();
        rows.add(createRow('الجلسات',));
        rows.add(createRow('الاعمال الادارية'));
        rows.add(SizedBox(height: 10)); // Adding space between text fields
        rows.add(createRow('الخارجيات'));
        rows.add(createRow('التنفيذ'));

      } else {
        rows.clear();
      }
    });
  }

  ButtonStyle _getButtonStyle(bool selected) {
    return ElevatedButton.styleFrom(
      backgroundColor: selected ? Colors.grey : Colors.purple,
    );
  }

  Widget createRow(String labelText) {
    return Padding(
      padding: EdgeInsets.only(top: 10), // Move text and text field down
      child: Row(
        children: [
          Text(labelText,
          style: TextStyle(
            color: Colors.white, // Default to black if no color is provided
          )),
          SizedBox(width: 10),
          Expanded(
            child: Theme(
              data: Theme.of(context).copyWith(
                inputDecorationTheme: InputDecorationTheme(
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.white), // Set focused border color
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.white), // Set enabled border color
                  ),
                ),
              ),
              child: TextField(
                decoration: InputDecoration(
                  // You can leave this empty since the theme defines the borders
                ),
              ),
            ),
          ),],
      ),

    );
  }
}
