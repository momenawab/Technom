import 'package:flutter/material.dart';

class ResetPasswordPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("img/back.jpg"), // Replace with your own image path
            fit: BoxFit.cover,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Spacer(),
            Image.asset(
              'img/logo.png', // Replace with your logo image path
              width: 120,
              height: 200,
            ),
            const SizedBox(height: 16.0),
            Text(
              "نسيت كلمة المرور",
              style: TextStyle(color: Colors.white, fontSize: 24),
            ),
            const SizedBox(height: 16.0),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: TextField(
                style: TextStyle(color: Colors.white),

                decoration: InputDecoration(
                  labelText: 'البريد الالكتروني',
                  labelStyle: TextStyle(color: Colors.white),


                ),
              ),
            ),
            const SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                // Perform reset password logic here
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.purple,
              ),
              child: Text(
                'ارسال الرمز',
                style: TextStyle(color: Colors.white),
              ),
            ),
            const SizedBox(height: 16.0),
            Spacer(),
          ],
        ),
      ),
    );
  }
}
