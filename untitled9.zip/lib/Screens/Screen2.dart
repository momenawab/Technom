import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'Screen3.dart';
import 'Screen4.dart';
import 'Screen5.dart';
import 'Screen6.dart';
import 'Screen7.dart';
import 'Screen8.dart';
import 'Screen11.dart';
import 'Screen12.dart';
import 'Profile.dart';

void main() {
  runApp(Screen2());
}

class Screen2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'استعلامات',
      debugShowCheckedModeBanner: false,
      home: ButtonPage(),
    );
  }
}

class ButtonPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: const Text(
          'استعلامات',
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ProfileApp()), // Navigate to ProfileApp
              );
            },
            icon: Icon(Icons.person), // You can use any icon you prefer
          ),
        ],
      ),
      body: Stack(
          children: [
            Container(
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('img/back.jpg'), // Replace with your image path
                  fit: BoxFit.cover,
                ),
              ),
            ),
            Positioned(
              bottom: 20,
              left: 150,
              child: Image.asset(
                'img/logo.png',
                width: 100,
                height: 100,
              ),
            ),
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      ElevatedButton(
                        onPressed: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => galasat()),);
                          // Add your button's onPressed logic here
                        },
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.purple),
                        child: const Text('جلسات خبراء'),
                      ),
                      const SizedBox(width: 10),
                      ElevatedButton(
                        onPressed: () { Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => ButtonApp()),);
                          // Perform forgot password logic here
                        },
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.purple),
                        child: const Text('جلسات'),
                      ),
                      const SizedBox(width: 10),
                      ElevatedButton(
                        onPressed: () {Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => MyyApp()),);

                          // Add your button's onPressed logic here
                        },
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.purple),
                        child: const Text('استعلام جلسات'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      ElevatedButton(
                        onPressed: () {Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => const MyAppp()),);
                          // Add your button's onPressed logic here
                        },
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.purple),
                        child: const Text('مالية'),
                      ),
                      const SizedBox(width: 10),
                      ElevatedButton(
                        onPressed: () {Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => const MyApp()),);
                          // Add your button's onPressed logic here
                        },
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.purple),
                        child: const Text('تحقيق'),
                      ),
                      const SizedBox(width: 10),
                      ElevatedButton(
                        onPressed: () { Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => Mange()),);
                          // Perform forgot password logic here
                        },
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.purple),
                        child: const Text('الاجرائات الادارية'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      ElevatedButton(
                        onPressed: () async {
                          FilePickerResult? result = await FilePicker.platform.pickFiles();
                          if (result != null) {
                            // The selected file will be in result.files.single
                            // You can implement your file uploading logic here
                            print('File path: ${result.files.single.path}');
                          } else {
                            // User canceled the file picking
                            print('File picking canceled');
                          }
                        },
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.purple),
                        child: const Text('Upload File'),
                      ),
                      const SizedBox(width: 20,),


                      ElevatedButton(
                    onPressed: () { Navigator.push(context, MaterialPageRoute(builder: (context) => mangement()),);
                      // Add your button's onPressed logic here
                    },
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.purple),

                    child: const Text('ادارة العمل'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ]),
    );
  }
}
