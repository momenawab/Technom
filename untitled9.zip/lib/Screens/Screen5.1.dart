import 'package:flutter/material.dart';
import 'Screen2.dart';

void main() {
  runApp(khesem());
}

class khesem extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  List<Widget> textFieldsRows = [];

  void addTextFieldRows() {
    List<Widget> rows = [];

    // First row with one TextField
    rows.add(
      Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Flexible(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                textDirection: TextDirection.rtl,
                style: TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: '◄ الاسم',
                  hintStyle: TextStyle(color: Colors.white),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.white),
                  ),
                  hintMaxLines: 1,
                  alignLabelWithHint: true,
                  hintTextDirection: TextDirection.rtl,
                  isDense: true,
                ),
              ),
            ),
          ),
        ],
      ),
    );

    // Add Arabic text between the rows
    rows.add(
      Padding(
        padding: const EdgeInsets.symmetric(vertical: 8.0),
        child: Align(
          alignment: AlignmentDirectional.centerEnd, // Align text to the right
          child: Text(
            ' بيانات الخصم  ◄   ',
            style: TextStyle(color: Colors.white),
          ),
        ),
      ),
    );

    // Second row with three TextFields
    List<Widget> rowTextFields = [];
    for (int i = 0; i < 3; i++) {
      rowTextFields.add(
        Flexible(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              textDirection: TextDirection.rtl,
              style: TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: '',
                hintStyle: TextStyle(color: Colors.white),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.white),
                ),
                hintMaxLines: 1,
                alignLabelWithHint: false,
                hintTextDirection: TextDirection.rtl,
                isDense: true,
              ),
            ),
          ),
        ),
      );
    }
    rows.add(Row(children: rowTextFields));

    setState(() {
      textFieldsRows.addAll(rows);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.home),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => Screen2()),
            );
          },
        ),
        title: const Text('الخصم'),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('img/back.jpg'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.only(top: kToolbarHeight),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const Text(
                    ' ',
                    textDirection: TextDirection.rtl,
                    style: TextStyle(fontSize: 20, color: Colors.white),
                  ),
                  const SizedBox(height: 40),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton(
                        onPressed: () {
                          addTextFieldRows();
                        },
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.purple),
                        child: const Text('إضافة الخصم'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  Column(
                    children: textFieldsRows,
                  ),
                  ElevatedButton(
                    onPressed: () {
                      // Save button functionality
                    },
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.purple),
                    child: const Text('حفظ'),
                  ),
                  SizedBox(height: 40),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
